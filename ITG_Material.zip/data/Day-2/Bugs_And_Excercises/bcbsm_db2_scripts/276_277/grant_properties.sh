#!/bin/bash
. ./grant_table.sh EDIDB2A SELECT DELETE CONTROL INSERT UPDATE REFERENCES






	
	



